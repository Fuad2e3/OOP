package org.example.db;

public class User {
    private String userName;
    private int userNumber;

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserNumber(int userNumber) {
        this.userNumber = userNumber;
    }

    public String getUserName() {
        return userName;
    }

    public int getUserNumber() {
        return userNumber;
    }
}


